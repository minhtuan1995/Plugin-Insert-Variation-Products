/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//
//$(window).load(function ()
//{
//    
//});

jQuery(document).ready(function($) {
//    console.log("START");
    setTimeout(function ()
    {
        var $contents = $('#iframe-insert-variations').contents();
        $contents.scrollTop($contents.height());
    }, 1000); // ms = 3 sec
});